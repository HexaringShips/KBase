﻿using IncidentManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace IncidentManagementSystem
{
    public class IncidentsController : ApiController
    {
        KBaseContext kbaseContext = new KBaseContext();
        public string AttachmentFilePath = "C:/Users/Anu Reddy/Downloads/FinalSolution/IncidentManagementSystem/KbaseContent/";
        [HttpGet]
        // GET api/<controller>
        public IEnumerable<Incident> GetIncidents()
        {
            return kbaseContext.Incidents.ToList<Incident>();
        }

        // GET api/<controller>/5
        public Incident Get(int id)
        {
            var result = kbaseContext.Incidents.SingleOrDefault(b => b.Id == id);
            return result;
        }
        [HttpPost]
        // POST api/<controller>
        public void PostIncident(Incident incident)
        {
            try
            {
                if (!Directory.Exists(AttachmentFilePath))
                    Directory.CreateDirectory(AttachmentFilePath);
                AttachmentFilePath = AttachmentFilePath + incident.UploadedFileName;
                File.WriteAllBytes(AttachmentFilePath, Convert.FromBase64String(incident.AttachmentPath));
                incident.CreatedBy = 1;
                incident.AttachmentPath = incident.UploadedFileName;
                kbaseContext.Incidents.Add(incident);
                kbaseContext.SaveChanges();
            }
            catch { }
        }
        [HttpPut]
        // PUT api/<controller>/5
        public void UpdateIncident(Incident incident)
        {
            try
            {
                var result = kbaseContext.Incidents.SingleOrDefault(b => b.Id == incident.Id);
                if (result != null)
                {
                    result.Title = incident.Title;
                    result.Keywords = incident.Keywords;
                    if (!string.IsNullOrEmpty(incident.AttachmentPath))
                    {
                        AttachmentFilePath = AttachmentFilePath + incident.UploadedFileName;
                        File.WriteAllBytes(AttachmentFilePath, Convert.FromBase64String(incident.AttachmentPath));
                        result.AttachmentPath = incident.UploadedFileName;
                    }
                    result.UpdatedDate = DateTime.Now;
                    result.Status = incident.Status;
                    result.Description = incident.Description;
                    if (incident.UpdatedBy == 0)
                    {
                        incident.UpdatedBy = result.CreatedBy;
                    }
                    kbaseContext.SaveChanges();
                }
            }
            catch { } 
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}