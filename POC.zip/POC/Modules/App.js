﻿


var itemApp = angular.module("gridApp",
    [      
        'ui.grid'
    ]);


itemApp.directive("fileread", [function () {
    return {
        scope: {
            fileread: "="
        },
        link: function (scope, element, attributes) {
            element.bind("change", function (changeEvent) {
                var reader = new FileReader();
                reader.onload = function (loadEvent) {
                    scope.$apply(function () {
                        scope.fileread = loadEvent.target.result;
                    });
                }
                reader.readAsDataURL(changeEvent.target.files[0]);
            });
        }
    }
}]);


itemApp.controller("gridController", ["$scope", "$filter", function ($scope, $filter) {

    $scope.scopeName = 'grid';
    $scope.myFile = {};
   

    $scope.items = [{
        id: 12232,
        name: 'Testing',
        description: 'Testing description',
        date: '01/07/2017',
        status : 'New'
    }, {
        id: 1241,
        name: 'Testing 2',
        description: 'Testing description 3',
        date: '01/07/2017',
        status: 'New'
    },
    {
        id: 1241,
        name: 'Testing 2',
        description: 'Testing description 3',
        date: '01/07/2017',
        status: 'New'
    }]

    var selectionCellTemplate = '<div class="ngCellText ui-grid-cell-contents">' +
               ' <div ng-click="grid.appScope.rowClick(row)">{{COL_FIELD}}</div>' +
               '</div>';

    $scope.rowClick = function (row) {
        $scope.mode = 'edit';
        $scope.editItem = row.entity;
    };

    $scope.mode = 'grid';
    
    $scope.gridOptions = {
        data: [],
        columnDefs: []
       
    }


    //$scope.gridOptions.onRegisterApi = function (gridApi) {
    //    //set gridApi on scope
    //    $scope.gridApi = gridApi;
    //    gridApi.selection.on.rowSelectionChanged($scope, doSelection);
    //};

    $scope.gridOptions.data = $scope.items;
    $scope.columns = [];

    


    var gridColumn = {
        displayName: 'ID',
        field: 'id',
        minWidth: 40,
        cellTemplate: selectionCellTemplate
    }

    $scope.columns.push(gridColumn);


    var gridColumn2 = {
        displayName: 'Name',
        field: 'name',
        minWidth: 40
    }

    $scope.columns.push(gridColumn2);

    var gridColumn3 = {
        displayName: 'Key Words',
        field: 'description',
        minWidth: 400
    }

    $scope.columns.push(gridColumn3);

    var gridColumn4 = {
        displayName: 'date',
        field: 'date',
        minWidth: 40
    }

    $scope.columns.push(gridColumn4);

    var gridColumn5 = {
        displayName: 'status',
        field: 'status',
        minWidth: 40
    }

    $scope.columns.push(gridColumn5);



    $scope.gridOptions.columnDefs = $scope.columns;
    $scope.title = 'Knowledge & Incident Logging Portal';

    $scope.addNew = function () {
        $scope.mode = 'add';
        $scope.addItem = {}
    }

    $scope.Search = {};
    $scope.SearchContent = function (data) {
        
        $scope.filteredItems = [];

        $scope.gridOptions.data = $filter('filter')($scope.items, data);
    }
    $scope.Add = function () {
        
        $scope.mode = 'grid';
        $scope.addItem.date = $filter('date')($scope.addItem.date, 'MM/dd/yyyy');
        $scope.items.push($scope.addItem);
        $scope.gridOptions.data = $scope.items;
    }

    $scope.Edit = function (item) {

        $scope.mode = 'grid';
        $scope.item.date = $filter('date')($scope.item.date, 'MM/dd/yyyy');
       
        _.each($scope.items, function (currentItem) {
           
            if (currentItem.id === item.id) {
                currentItem = item;
            }

        });
        $scope.gridOptions.data = $scope.items;
    }

   
}]);






