﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IncidentManagementSystem.Models
{
    public partial class Incident
    {
        public string UploadedFileName { get; set; }
    }
}