﻿using IncidentManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace IncidentManagementSystem
{
    public class IncidentsController : ApiController
    {
        KBaseContext kbaseContext = new KBaseContext();

        [HttpGet]
        // GET api/<controller>
        public IEnumerable<Incident> GetIncidents()
        {
            return kbaseContext.Incidents.ToList<Incident>();
        }

        // GET api/<controller>/5
        public Incident Get(int id)
        {
            var result = kbaseContext.Incidents.SingleOrDefault(b => b.Id == id);
            return result;
        }
        [HttpPost]
        // POST api/<controller>
        public void PostIncident(Incident incident)
        {
            incident.CreatedBy = 1;
            kbaseContext.Incidents.Add(incident);
            kbaseContext.SaveChanges();
        }
        [HttpPut]
        // PUT api/<controller>/5
        public void UpdateIncident(int id, Incident incident)
        {
            var result = kbaseContext.Incidents.SingleOrDefault(b => b.Id == id);
            if (result != null)
            {
                result.Title = incident.Title;
                result.Keywords = incident.Keywords;
                result.AttachmentPath = incident.AttachmentPath;
                result.UpdatedDate = DateTime.Now;
                result.Status = incident.Status;
                result.Description = incident.Description;
                if (incident.UpdatedBy == 0) {
                    incident.UpdatedBy = result.CreatedBy;
                }
                kbaseContext.SaveChanges();
            }
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}